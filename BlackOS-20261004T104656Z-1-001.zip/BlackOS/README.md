# BlackOS

An ultra-light, dark XFCE Linux distro built to revive old ("potato") PCs for gaming.
Built on Debian with `live-build`. **Target: 1GB RAM minimum.**

Made by ymp.

- Pitch-black theme, Windows-style layout (bottom taskbar, start menu, tray, volume, clock)
- File manager: **my bud** (currently PCManFM, branded and set as the default)
- Task manager: LXTask
- Audio: PipeWire with a volume applet in the panel
- Compressed RAM swap (zram) and trimmed background services
- No telemetry, no popularity-contest, no auto-updating timers

> **Status:** early and community-tested. The build script passes a syntax check,
> but a full build and boot has not been verified on real hardware yet.

---

## Files in this folder

| File | What it is |
|------|------------|
| `build-blackos.sh` | The build script. Run this. |
| `blackos-wallpaper.png` | The default wallpaper. Must sit next to the script. |
| `README.md` | This file. |

---

## 1. What you need

- A **Debian or Ubuntu** computer to build on (a VM is fine)
- About **10GB free disk space** and an internet connection
- Root access (`sudo`)
- Roughly 10 to 30 minutes for the build

Install the build tools:

```
sudo apt update
sudo apt install live-build debootstrap debian-archive-keyring
```

Note: building Debian *trixie* on an older Ubuntu host can fail because its
`debootstrap` doesn't know about trixie yet. If that happens, build on a
Debian host, update `debootstrap`, or use `SUITE=bookworm`.

## 2. Build the ISO

Put `build-blackos.sh` and `blackos-wallpaper.png` in the same folder, then:

```
chmod +x build-blackos.sh
sudo ./build-blackos.sh
```

The finished image is at:

```
build/live-image-amd64.hybrid.iso
```

If anything goes wrong, read `build/build.log`. The last 30 lines usually show
which package or step failed.

### Build options

Set these as environment variables and use `sudo -E`:

| Variable | Values | Default | Meaning |
|----------|--------|---------|---------|
| `SUITE` | `trixie`, `bookworm` | `trixie` | Debian release |
| `ARCH` | `amd64`, `i386` | `amd64` | CPU architecture |
| `INSTALLER` | `live`, `none` | `live` | Include the disk installer in the boot menu |

Examples:

```
# 32-bit (very old CPUs). Debian trixie dropped i386, so use bookworm:
SUITE=bookworm ARCH=i386 INSTALLER=none sudo -E ./build-blackos.sh

# Live-only image, no installer:
INSTALLER=none sudo -E ./build-blackos.sh
```

For 32-bit builds the script uses the non-PAE `686` kernel so pre-PAE CPUs can boot.
Debian's i386 installer kernel may still need PAE, so for those CPUs use
`INSTALLER=none` and run BlackOS from a USB stick.

Builds are cached in `.lb-cache/` so rebuilding is faster. Delete that folder to
force a clean download.

## 3. Test it in a VM first (recommended)

Always boot it in a virtual machine before real hardware. With QEMU:

```
sudo apt install qemu-system-x86 ovmf

# BIOS mode, 1GB RAM:
qemu-system-x86_64 -m 1024 -enable-kvm -cdrom build/live-image-amd64.hybrid.iso -boot d

# UEFI mode:
qemu-system-x86_64 -m 1024 -enable-kvm -bios /usr/share/ovmf/OVMF.fd \
  -cdrom build/live-image-amd64.hybrid.iso -boot d
```

VirtualBox or VMware work too: create a Linux (Debian 64-bit) VM with 1GB RAM and
attach the ISO. Test both BIOS and UEFI if you can.

## 4. Put it on a USB stick

Use balenaEtcher, or Ventoy, or `dd`:

```
sudo dd if=build/live-image-amd64.hybrid.iso of=/dev/sdX bs=4M status=progress conv=fsync
```

**Warning:** replace `/dev/sdX` with your USB stick. Pick the wrong device and
`dd` will erase that disk. Check with `lsblk` first.

## 5. Logging in

BlackOS boots straight to the desktop and logs in automatically as:

- user: `user`
- password: `live` (if anything asks for one)

This is normal for a live USB. If you install it to a disk, change the password.

## 6. Installing to a disk

If built with `INSTALLER=live` (the default), the boot menu has an installer entry
(Debian's lightweight text installer). If built with `INSTALLER=none`, BlackOS only
runs live from USB.

### Keeping files without installing (persistence)

Boot the live USB with the `persistence` boot parameter and add a partition
labelled `persistence` containing a file named `persistence.conf` with the line
`/ union`.

## 7. Customizing

- **Wallpaper:** replace `blackos-wallpaper.png` before building. By default it is
  scaled to fit the screen on a black background. In the script, change `--bg-max`
  to `--bg-fill` to fill the screen instead (this crops the edges).
- **Packages:** edit the package list inside `build-blackos.sh`.
- **File manager:** `my bud` currently launches PCManFM. To use your own file
  manager later, edit the `/usr/local/bin/mybud` launcher section of the script.
- **Extra speed on very old CPUs:** add `mitigations=off` to the boot line in the
  script. This is a real security trade-off, so it is off by default.

## 8. Troubleshooting

| Problem | Try this |
|---------|----------|
| Build stops on a package name | Check `build/build.log`; the package may not exist in your chosen `SUITE` |
| "Mounts are still active" | A previous build was interrupted. Reboot, then run the script again |
| Build fails right at the start on Ubuntu | Your `debootstrap` is too old for the suite. Use a Debian host or `SUITE=bookworm` |
| No Wi-Fi | Firmware for your card may be missing. Tell us your card model |
| USB drives don't mount | Report it with your hardware details |
| Wallpaper looks wrong | Check your screen size; see the wallpaper note above |

## 9. Known limitations

- Not yet verified on real hardware.
- GTK4/libadwaita apps ignore the black GTK3 theme.
- 1GB RAM is the target. Heavy apps and browsers will struggle on that.
- Steam is not included.

## 10. Testing BlackOS (for testers)

Thanks for helping! Please report:

```
CPU:
GPU:
RAM:
Boot mode (BIOS / UEFI):
Booted OK? (yes / no):
Wi-Fi works? (yes / no / no card):
Sound works? (yes / no):
USB drives mount? (yes / no):
Idle RAM after login (run: free -m):
Wallpaper looks right? (yes / no, screen size):
Installer works? (yes / no / not tried):
Anything else:
```

## 11. Sharing it

- Publish the build script with the ISO so people can see how it is made.
- Publish a checksum next to the ISO:

```
sha256sum build/live-image-amd64.hybrid.iso > SHA256SUMS
```

BlackOS is made from Debian packages, each with its own license, and includes
non-free firmware for hardware support.

## Credits

Made by ymp. Built on Debian and `live-build`.
